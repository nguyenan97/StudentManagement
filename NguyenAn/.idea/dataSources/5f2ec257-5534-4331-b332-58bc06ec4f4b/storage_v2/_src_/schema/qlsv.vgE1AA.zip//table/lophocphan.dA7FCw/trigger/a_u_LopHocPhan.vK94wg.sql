CREATE TRIGGER a_u_LopHocPhan
  AFTER UPDATE
  ON lophocphan
  FOR EACH ROW
  BEGIN						SET @time_mark = DATE_ADD(NOW(), INTERVAL 50400 SECOND); 						SET @tbl_name = 'LopHocPhan';						SET @pk_d_old = CONCAT('<MaHP>',OLD.`MaHP`,'</MaHP>');						SET @pk_d = CONCAT('<MaHP>',NEW.`MaHP`,'</MaHP>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END;

