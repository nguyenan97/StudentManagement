CREATE TRIGGER a_d_GiangVien
  AFTER DELETE
  ON giangvien
  FOR EACH ROW
  BEGIN						SET @time_mark = DATE_ADD(NOW(), INTERVAL 50400 SECOND); 						SET @tbl_name = 'GiangVien';						SET @pk_d = CONCAT('<MaGV>',OLD.`MaGV`,'</MaGV>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END;

